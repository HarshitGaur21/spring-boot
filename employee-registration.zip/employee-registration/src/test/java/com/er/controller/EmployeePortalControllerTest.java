package com.er.controller;

import static org.junit.Assert.*;

import java.util.TreeSet;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.er.dto.Employee;
import com.er.dto.EmployeeRegistrationResponse;
import com.er.dto.EmployeeRetrievalResponse;
import com.er.main.EmployeePortalSelfServiceHost;
import com.er.service.EmployeeRegistrationService;
import com.er.service.EmployeeRetrievalService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes=EmployeePortalSelfServiceHost.class)
@WebMvcTest(EmployeePortalController.class)
public class EmployeePortalControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private  EmployeeRegistrationService registrationService;

	@MockBean
	private  EmployeeRetrievalService retrievalService;

	String content = "{\\\"firstName\\\":\\\"Harshit\\\",\\\"lastName\\\":\\\"Gaur\\\",\\\"gender\\\":\\\"Male\\\",\\\"dob\\\":\\\"21/12/1989\\\",\\\"department\\\":\\\"Tech\\\"}";
	
	@Test
	public void testRegisterEmployee() throws Exception {
		Employee emp = new Employee("Harshit", "Gaur", "Male", "21/12/1989", "Tech");
		EmployeeRegistrationResponse sampleResponse = new EmployeeRegistrationResponse(true, emp, HttpStatus.CREATED);
		Mockito.when(
				registrationService.registerEmployee(
						Mockito.any(Employee.class))).thenReturn(sampleResponse);

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/registerEmployee")
				.accept(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(emp))
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.CREATED.value(), response.getStatus());


	}

	@Test
	public void testRetrieveEmployee() throws Exception {
		Employee emp = new Employee("Harshit", "Gaur", "Male", "21/12/1989", "Tech");
		TreeSet<Employee> employees = new TreeSet<>();
		employees.add(emp);
		EmployeeRetrievalResponse sampleResponse = new EmployeeRetrievalResponse(employees, HttpStatus.OK);
		Mockito.when(
				retrievalService.retrieveEmployee(
						)).thenReturn(sampleResponse);

		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.get("/listEmployees")
				.accept(MediaType.APPLICATION_JSON).content(new ObjectMapper().writeValueAsString(emp))
				.contentType(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		
		assertEquals(HttpStatus.OK.value(), response.getStatus());


	}
}
