package com.er.repository;

import java.util.TreeSet;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import com.er.dto.Employee;

@Repository
public class EmployeeRepository {

	TreeSet<Employee> employees;
	
	@PostConstruct
	public void initializeRepo() {
		employees = new TreeSet<>();
	}
	
	public boolean insertEmployee(Employee emp) {
		return employees.add(emp);
	}
	
	public TreeSet<Employee> retrieveEmployees() {
		
		return employees;
	}
}
