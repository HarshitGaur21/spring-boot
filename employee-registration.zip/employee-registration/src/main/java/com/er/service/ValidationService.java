package com.er.service;

import java.util.Objects;

import org.springframework.stereotype.Service;

import com.er.dto.Employee;

@Service
public class ValidationService {

	public boolean isRegistrationRequestValid(Employee emp) {
		if(Objects.isNull(emp)) {
			return false;
		}
		if(Objects.isNull(emp.getFirstName())) {
			return false;
		}
		if(emp.getFirstName().trim().equals("")) {
			return false;
		}
		return true;
	}
}
