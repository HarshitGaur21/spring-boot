package com.er.service;

import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.er.dto.Employee;
import com.er.dto.EmployeeRetrievalResponse;
import com.er.repository.EmployeeRepository;

@Service
public class EmployeeRetrievalService {

	@Autowired
	EmployeeRepository repository;

	public EmployeeRetrievalResponse retrieveEmployee() {
		TreeSet<Employee> employees = repository.retrieveEmployees();
		return new EmployeeRetrievalResponse(employees, employees.isEmpty() ? HttpStatus.NOT_FOUND : HttpStatus.OK);
	}
}
