package com.er.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.er.dto.Employee;
import com.er.dto.EmployeeRegistrationResponse;
import com.er.repository.EmployeeRepository;

@Service
public class EmployeeRegistrationService {

	@Autowired
	EmployeeRepository repository;

	@Autowired
	ValidationService validationService;

	public EmployeeRegistrationResponse registerEmployee(Employee emp) {
		if (!validationService.isRegistrationRequestValid(emp)) {
			return new EmployeeRegistrationResponse(false, emp, HttpStatus.BAD_REQUEST);
		}
		boolean isRegistrationSuccessful = repository.insertEmployee(emp);
		return new EmployeeRegistrationResponse(isRegistrationSuccessful, emp,
				isRegistrationSuccessful ? HttpStatus.CREATED : HttpStatus.CONFLICT);
	}
}
