package com.er.config;

import io.swagger.annotations.Info;
import io.swagger.annotations.SwaggerDefinition;

@SwaggerDefinition(
        info = @Info(
                description = "Employee Portal",
                version = "V12.0.12",
                title = "Employee Portal"
        ),
        consumes = {"application/json"},
        produces = {"application/json"}
)
public interface ApiDocumentationConfig {

}
