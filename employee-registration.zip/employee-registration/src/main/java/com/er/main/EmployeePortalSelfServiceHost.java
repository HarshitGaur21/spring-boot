package com.er.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = { "com.er.controller","com.er.service", "com.er.repository", "com.er.config"} )
public class EmployeePortalSelfServiceHost {

	
	public static void main(String[] args) {
		SpringApplication.run(EmployeePortalSelfServiceHost.class, args);

	}

}
