package com.er.dto;

import org.springframework.http.HttpStatus;

public class EmployeeRegistrationResponse {

	private boolean isRegistrationSuccessful;
	private Employee registeredEmployee;
	private HttpStatus httpStatus;

	public EmployeeRegistrationResponse(boolean isRegistrationSuccessful, Employee registeredEmployee) {
		super();
		this.isRegistrationSuccessful = isRegistrationSuccessful;
		this.registeredEmployee = registeredEmployee;
	}

	public EmployeeRegistrationResponse(boolean isRegistrationSuccessful, Employee registeredEmployee,
			HttpStatus httpStatus) {
		super();
		this.isRegistrationSuccessful = isRegistrationSuccessful;
		this.registeredEmployee = registeredEmployee;
		this.httpStatus = httpStatus;
	}

	public boolean isRegistrationSuccessful() {
		return isRegistrationSuccessful;
	}

	public void setRegistrationSuccessful(boolean isRegistrationSuccessful) {
		this.isRegistrationSuccessful = isRegistrationSuccessful;
	}

	public Employee getRegisteredEmployee() {
		return registeredEmployee;
	}

	public void setRegisteredEmployee(Employee registeredEmployee) {
		this.registeredEmployee = registeredEmployee;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
}
