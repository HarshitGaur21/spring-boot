package com.er.dto;

import java.util.TreeSet;

import org.springframework.http.HttpStatus;

public class EmployeeRetrievalResponse {

	private TreeSet<Employee> employees;
	private HttpStatus httpStatus;

	public EmployeeRetrievalResponse(TreeSet<Employee> employees) {
		super();
		this.employees = employees;
	}

	public EmployeeRetrievalResponse(TreeSet<Employee> employees, HttpStatus httpStatus) {
		super();
		this.employees = employees;
		this.httpStatus = httpStatus;
	}

	public TreeSet<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(TreeSet<Employee> employees) {
		this.employees = employees;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}
}
