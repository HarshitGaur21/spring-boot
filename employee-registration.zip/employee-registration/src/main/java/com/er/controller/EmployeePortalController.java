package com.er.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.er.dto.Employee;
import com.er.dto.EmployeeRegistrationResponse;
import com.er.dto.EmployeeRetrievalResponse;
import com.er.service.EmployeeRegistrationService;
import com.er.service.EmployeeRetrievalService;

@RestController
public class EmployeePortalController {

	@Autowired
	EmployeeRegistrationService registrationService;

	@Autowired
	EmployeeRetrievalService retrievalService;

	@GetMapping("/healthCheck")
	public String healthCheck() {
		return "Hey there, I am up and running!!";
	}

	@PostMapping("/registerEmployee")
	public ResponseEntity<EmployeeRegistrationResponse> registerEmployee(@RequestBody Employee emp) {
		EmployeeRegistrationResponse result = registrationService.registerEmployee(emp);
		ResponseEntity<EmployeeRegistrationResponse> reponse = new ResponseEntity<EmployeeRegistrationResponse>(result,
				result.getHttpStatus());
		return reponse;

	}

	@GetMapping("/listEmployees")
	public ResponseEntity<EmployeeRetrievalResponse> listEmployee() {
		EmployeeRetrievalResponse result = retrievalService.retrieveEmployee();
		return new ResponseEntity<EmployeeRetrievalResponse>(result, result.getHttpStatus());
	}
}
